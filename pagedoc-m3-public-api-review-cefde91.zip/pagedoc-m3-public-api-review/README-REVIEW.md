# PageDoc M3.2 — public API review bundle

Source: feature/m3-public-api @ cefde91fd94c6d5cc81084884f93bec0a246b602
Prompt: PAGEDOC-M3-004

Contents:
- api/            public contract, inspection schema samples, CLI/API parity
- packaging/      wheel contents + isolated-install smoke result
- regressions/    byte-identity for layout galleries + composition regression
- docs/           PUBLIC_API.md as shipped
- review-manifest.json  machine-readable evidence + per-artifact hashes
