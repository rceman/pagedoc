# PageDoc M2 — Visual Review Bundle

This bundle packages the Milestone 2 candidate for **independent visual
acceptance** before M2 is merged. No implementation changes should be
inferred from this archive. It represents source SHA
`e0bfbfeef6430b62190d74f1311f7916504447a8`
(branch `feature/m2-fixed-page-layout` of `rceman/pagedoc`;
`main` = `1fe9c5e05f0fc59fac85cf8e39d109c2b7a60c00`).

## Contents

### visual-primitives/

Conformance corpus for geometric visual primitives (markers, connectors,
borders, badges, component boundaries).

- `visual-primitives.pdf` — the **vector** PDF (primary M2 output;
  searchable, resolution-independent).
- `visual-primitives.flattened.pdf` — experimental **pixel-locked** PDF:
  each page is one raster image derived from the validated vector PDF at
  144 DPI.
- `pdfium/page-00N.png` — vector PDF rendered by **PDFium** at 288 DPI.
- `mupdf/page-00N.png` — vector PDF rendered by **MuPDF** at 288 DPI.
- `flattened-pdfium/page-00N.png` — flattened PDF rendered by **PDFium**
  at 288 DPI.
- `contact-sheet.png` — labelled side-by-side navigation aid
  (full-resolution PNGs are in the folders above).
- `source/` — exact authored fixture inputs (document manifest,
  `.book.md` pages, SVG marker assets).

### layout-gallery/

10-page representative layout corpus.

- `layout-gallery.pdf` — vector PDF (10 pages).
- `layout-gallery.flattened.pdf` — experimental flattened PDF.
- `layout-gallery.html` — deterministic generated HTML.
- `layout-gallery.inspect.json` — machine-readable layout metrics
  (per-page fit, usage, resolved presets).
- `pdfium/page-001..010.png` — vector PDF rendered by PDFium at 192 DPI.
- `contact-sheet.png` — labelled overview of all 10 pages.
- `source/` — authored fixture inputs.

### review-manifest.json

Machine-readable manifest: source SHAs, per-artifact SHA-256 + bytes,
PDF page counts/dimensions, renderer versions/DPI, font hashes, test
result. Verify any file with
`sha256sum <file>` against the manifest entry.

## What to inspect manually

- centered circle + inner-dot geometry (all three marker sizes)
- marker alignment identical between PDFium and MuPDF renders
- flow connectors (shaft + arrowhead between steps)
- 1px / 2px / 3px border panels; rounded corners
- compare separators between horizontal sides
- row alignment (equal / wide-left splits)
- browser/address bar primitives and Secure cue
- warning cue (geometric disc + WARNING label)
- small mono text rendering
- page margins and region boundaries
- clipping at page/region edges (there should be none)
- font rendering consistency (Inter / Roboto Mono)
- vector vs flattened PDF geometry (round-trip)
- overall visual quality of all 10 gallery pages

## Versions

- WeasyPrint 66.0 (authoritative layout engine)
- PDFium 153.0.7999.0 via pypdfium2 5.13.0 (raster validation only)
- MuPDF 1.28.2 via PyMuPDF 1.28.2 (raster validation only)
- img2pdf 0.6.3 (flattened assembly)
- Python 3.12.3
- Test baseline at this SHA: `.venv/bin/python -m pytest tests` →
  165 passed, 0 failed, 0 skipped.
