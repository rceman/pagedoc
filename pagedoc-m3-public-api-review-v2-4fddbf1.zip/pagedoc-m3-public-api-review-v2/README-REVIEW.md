# PageDoc M3.2 — public API review bundle v2

Source: feature/m3-public-api @ 4fddbf19fb2200fec6f9a0ef6889c46b4e9277c2
Prompt: PAGEDOC-M3-005

v2 corrects InspectionReport ownership: constructor deep-copies the
payload, diagnostics returns frozen Diagnostic values, to_dict()
returns an independent deep copy. Schema stays v1; rendered output is
byte-identical.

Contents:
- api/            public contract, inspection schema samples,
                  immutability evidence, CLI/API parity
- packaging/      wheel contents + isolated-install smoke result
- regressions/    byte-identity for layout galleries + composition regression
- docs/           PUBLIC_API.md as shipped
- review-manifest.json  machine-readable evidence + per-artifact hashes
