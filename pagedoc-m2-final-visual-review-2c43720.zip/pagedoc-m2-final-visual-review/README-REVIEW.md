# PageDoc M2 — Final Visual Review Bundle (footer-logo stability fix)

Final M2 visual-acceptance bundle. Source SHA:
`2c4372033302f3ba90ec1bb86088fd0a507b9466`
(branch `feature/m2-fixed-page-layout-final`, repo `rceman/pagedoc`).
**No external consumer repository was inspected or used.**

## What this bundle proves

The previous review found a defect: the masked `footer-logo.svg` rendered
correctly only on vector-PDF page 1; pages 2–10 contained a corrupted
variant, and a second serialization of the same `RenderedDocument`
corrupted page 1 as well. Both PDFium and MuPDF showed the corruption —
it was in the PDF, not a viewer difference.

The fix: the mask (`mask(shield ∩ rect)`) is flattened into a direct
right-half path — `footer-logo.svg` is now mask-free vector geometry
with the same silhouette, gray right half, white face, and blue border.
The original masked artwork is preserved for provenance as
`footer-logo-reference.svg` (not used by the theme).

## Evidence to check

1. **Ten identical logos** — `footer-logo/footer-logo-sheet.png`: all 10
   page crops side by side. `review-manifest.json` carries a per-page
   SHA-256 for each logo crop — expect 1 unique hash.

2. **Cross-renderer** — `footer-logo/footer-logo-cross-renderer.png`:
   PDFium vs MuPDF for pages 1, 2, 10.

3. **Vector vs flattened** — `book/layout-gallery-book-v2.pdf` vs
   `layout-gallery-book-v2.flattened.pdf` (96 DPI). Per-page differing
   pixel counts are in the manifest — all 0.

4. **Serialization stability** — manifest lists SHA-256 for
   `pdf_bytes()` ×2 and `write_pdf()` of the same `RenderedDocument` —
   all identical.

5. **Shell regression** — `sidebar/sidebar-sheet.png` and
   `book/contact-sheet.png`: sidebar markers/label, header bands,
   footer composition all unchanged from the accepted parity state.

6. **Default regression** — `default-regression/`: the default theme is
   untouched and deterministic.

7. **Full pages** — `book/pdfium/page-001..010.png` (96 DPI native
   2500×2500) + `book/mupdf/` representative pages.

## Versions

WeasyPrint 66.0 · PDFium 153.0.7999.0 (pypdfium2 5.13.0) ·
MuPDF 1.28.2 (PyMuPDF 1.28.2) · img2pdf 0.6.3 · Python 3.12.3.
Tests: `.venv/bin/python -m pytest tests` → 205 passed.
