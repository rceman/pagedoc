# PageDoc M3.1 composition review bundle

Source: `feature/m3-composition-core` @ `52cf5e347b5fa5252b8d673a5082f851dc6711f9`

M3.1 replaces the coarse M2 fallback ("flip every still-horizontal
auto node on a failing page") with a bounded, page-local, exact
Cartesian search over authored `auto` decisions, evaluated through the
real WeasyPrint layout pass.

## What to confirm visually

- `composition-gallery.pdf` / `pdfium/page-*.png` / `contact-sheet.png`:

  - page 1 (`cmp-compare-recovery`): compare renders **vertical**; a
    2-candidate search changed only that node (deviation 1).
  - page 2 (`cmp-localized-auto`): the overflowing compare goes
    vertical **while the small flow stays horizontal** — the core
    proof that independent autos are changed individually (M2 flipped
    every auto on the page).
  - page 3 (`cmp-row-recovery`): the backend-chosen `wide-right` split
    gives the verbose note column visibly more room; preferred
    `wide-left` and `equal` overflowed.
  - page 4 (`cmp-mixed-recovery`): the unique fitting combination of
    `wide-right` row + `vertical` compare out of a 6-assignment space.
  - page 5 (`cmp-flow-recovery`): flow with long endpoint strings
    renders **vertical** (horizontal overflowed width).
  - page 6 (`cmp-multi-auto`): compare vertical, deviation 1.

- `composition-gallery.inspect.json` carries the full structured
  trace: every decision, candidate-space size, per-assignment
  measurements (fits, overflow, content used/available, deviations,
  blocks rendered/missing), and the selected resolution.

- Pages that already fit are intentionally **not** recomposed —
  composition search is overflow recovery, not automatic restyling.
  `regressions/` shows the default and Book v2 galleries render
  byte-identical PDFs to the M2 baseline with exactly 1 layout pass.

- `benchmark/benchmark-output.json`: pass counts and timings for both
  galleries (tooling reference, not a CI gate).
