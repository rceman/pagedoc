# PageDoc M2 — Book v2 Shell Parity Review Bundle

Corrected `book-v2-reference` theme aligned to the current Book v2.2.1
shell geometry/typography, plus the new generic theme-local CSS image
asset mechanism. Source SHA:
`294b33b886b0ccfd243cfa6392e2a6f59dcc60f6` (branch
`feature/m2-fixed-page-layout-final`, repo `rceman/pagedoc`).

**This bundle does NOT contain or depend on an external consumer
repository.** All reference values were supplied in the task; the theme
is a standalone example under `examples/themes/book-v2-reference/`.

## What to review

1. **Sidebar** — `sidebar-sheet.png` (full-height crops, pages 1/4/7/10):
   gold Roboto Mono 80px "ETHICAL HACKING" rotated at the supplied
   position; top + bottom markers are the same `sidebar-marker.svg`
   (48×48 viewBox, shared cx=24 cy=24 → concentric by construction) at
   bounds x101..149 / y101..149 and y2351..2399.

2. **Header** — upper band: shell #181a29, white Inter Regular 150px
   centered (no uppercase, no letter-spacing, no bold); lower band:
   black, blue #1da1f2 Inter Regular 110px; no blue separator border.

3. **Footer** — `footer-sheet.png` (full-width crops, pages 1/4/7/10):
   supplied `footer-logo.svg` at 42,48 138×154 (the masked SVG renders
   correctly in both WeasyPrint→PDFium and →MuPDF — no flattened
   fallback was required); `#BUGBOUNTY` Roboto Mono 120px at 764,18;
   "Tips and Tricks Vol.1" 48px at 822,150; red disclaimer box 414×153,
   6px border, 40px/50px at 1547,52; visible page number is a single
   120px CSS counter (1, 4, 7, 10…) at right:100, top:35 — the generic
   `N / 10` text remains in the DOM but is not rendered.

4. **Markers concentric** — measured centers at 288 DPI: PDFium and
   MuPDF both report (125,125) and (125,2375) exactly; outer-vs-inner
   delta 0.00 CSS px. See `review-manifest.json`.

5. **Theme-local assets** — `shell-assets/` holds the two SVGs the theme
   loads through the new generic mechanism: `url("assets/…")` in
   theme.css resolves against the theme dir and inlines as base64
   `data:` URIs. Remote/file/absolute/traversal targets are rejected.

6. **Content unchanged** — same 10 `.book.md` sources as the default
   theme; intrinsic sizing; all pages fit; 10 logical = 10 physical;
   `inspect.json` has per-page used/available heights.

7. **Vector vs flattened** — `layout-gallery-book-v2.pdf` (canonical
   vector) vs `layout-gallery-book-v2.flattened.pdf` (optional, 96 DPI).
   Representative pages compare pixel-identical.

8. **Default regression** — `default-regression/` has the unchanged
   default-theme gallery PDF + representative rasters; output is
   byte-deterministic (repeat render hash-identical).

## Folders

- `book-v2-parity/` — corrected Book theme output (PDFs, inspect.json,
  PDFium 96-DPI rasters ×10, MuPDF 96-DPI rasters ×6, contact/footer/
  sidebar sheets).
- `default-regression/` — default-theme vector PDF + 4 page rasters.
- `shell-assets/` — the two theme SVGs (provenance).
- `source/` — corrected theme.yaml, theme.css, document-book-v2.yaml.
- `review-manifest.json` — sizes, SHA-256, versions, measured marker
  centers, font families, test result.

## Versions

WeasyPrint 66.0 · PDFium 153.0.7999.0 (pypdfium2 5.13.0) ·
MuPDF 1.28.2 (PyMuPDF 1.28.2) · img2pdf 0.6.3 · Python 3.12.3.
Tests: `.venv/bin/python -m pytest tests` → 200 passed.
