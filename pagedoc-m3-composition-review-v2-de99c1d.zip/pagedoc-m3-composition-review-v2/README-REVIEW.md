# PageDoc M3.1 composition review bundle — v2 (visual-integrity correction)

Source: `feature/m3-composition-core` @ `de99c1d4e0650634b008da9388b03aca74cb5b76`

This bundle verifies the two corrections made after the v1 review:

1. **Intrinsic vertical sizing.** Vertical `compare`/`flow` children in
   both first-party themes now use `flex: 0 0 auto` instead of
   `flex: 1 1 0`, so each side/step keeps its intrinsic content height
   and nothing escapes into a sibling block.

2. **Honest trace outcomes.** Searched pages emit
   `outcome: selected | no-fit | too-many-candidates` — never the
   contradictory `not-searched`.

## What to confirm

- `composition-gallery/overlap/vertical-overlap-check.png` — high-res
  crop of the corrected page 6 boundary: last checklist items of side
  1, separator, AFTER label, Migrated. — no collision.
- `composition-gallery/overlap/text-bboxes.json` — MuPDF text-box
  evidence: side-1 last text bottom 551.6pt, side-2 first text top
  573.03pt, gap +21.4pt, `overlap: false`.
- `composition-gallery/pdfium/` + `mupdf/` — the corrected page in
  both renderers.
- `composition-gallery/contact-sheet.png` — all six gallery pages;
  page 2 still shows only the compare changing (flow stays
  horizontal); page 3 wide-right row; page 4 wide-right + vertical
  compare; page 5 vertical flow.
- `composition-gallery.inspect.json` — every searched page reports
  `outcome: selected` with candidate measurements.
- `regressions/` — the only changed page in each legacy gallery is
  page 6 (`06-compare-vertical`), which is the intentional intrinsic
  fix; all other pages pixel-identical.
