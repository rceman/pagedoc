# PageDoc M2 — Book Theme Visual Review Bundle

Independent visual-acceptance bundle for M2 multi-theme support.
Source SHA: `de1e00ac9c11d548b8882fc28bae0f58b2285b8f`
(branch `feature/m2-fixed-page-layout-final`, repository
`rceman/pagedoc`). **This bundle does NOT contain or depend on an
external consumer repository** — the Book v2 theme is a standalone
example theme defined entirely by `book-v2-theme/source/theme.yaml` +
`theme.css` in this archive.

## What to compare

1. **Default vs Book theme, identical source** — `theme-comparison/
   default-vs-book-v2-contact-sheet.png` shows all 10 gallery pages
   side by side (DEFAULT left, BOOK V2 right). Same `.book.md`, same
   AST, same page IDs — only the theme differs.

2. **Book shell** — square 2500×2500 page; left dark sidebar with two
   geometric ring+dot markers and a vertical label; upper header band
   (dark, white group text); lower header band (black, blue page
   title); content region; footer with gold branding, page id, blue
   page number, red outlined box.

3. **Book visual language** — black page, dark panels, light technical
   surfaces for request/response/code, Roboto Mono mono text, Inter
   prose, blue/gold/green/red accents, visible borders and separators.

4. **Intrinsic layout** — no authored heights/widths anywhere in page
   source; components are content-sized; no clipping; every page
   reports fit=PASS in `book-v2-theme/layout-gallery-book-v2.inspect.json`.

5. **Vector vs flattened** — `book-v2-theme/layout-gallery-book-v2.pdf`
   (vector, canonical) vs `layout-gallery-book-v2.flattened.pdf`
   (experimental image-only PDF at 96 DPI). `vector-vs-flat-contact-sheet.png`
   compares pages 1, 3, 4, 7, 9, 10 — identical geometry.

6. **Fixed raw ampersand** — `reviewed-fixes/04-request-note.book.md`
   authors a literal `&` in the HTTP request line; it renders
   literally (see Book page 4 and default page 4).

7. **Badge SVG without system-font text** — `reviewed-fixes/badge.svg`
   contains zero `<text>` elements (geometric bars inside the pill),
   so no host font is pulled into the conformance PDF.

8. **All 10 square pages at native resolution** — `book-v2-theme/
   pdfium/page-001..010.png` are full 2500×2500 PDFium rasters (96 DPI
   = native CSS px). `book-v2-theme/contact-sheet.png` is a labelled
   overview.

## Folders

- `default-theme/` — default A4-ratio theme: vector PDF + PDFium
  rasters (144 DPI).
- `book-v2-theme/` — Book v2 reference theme: vector + flattened PDF,
  inspect JSON, 96-DPI rasters, contact sheets, theme source.
- `theme-comparison/` — side-by-side contact sheet.
- `visual-primitives/` — geometry conformance corpus: vector +
  flattened PDF, PDFium and MuPDF rasters at 288 DPI, contact sheet.
- `review-manifest.json` — SHA-256 + sizes for every artifact,
  tool versions, test result. Verify with `sha256sum`.

## Versions

WeasyPrint 66.0 (layout engine) · PDFium 153.0.7999.0 via pypdfium2
5.13.0 · MuPDF 1.28.2 via PyMuPDF 1.28.2 · img2pdf 0.6.3 ·
Python 3.12.3. Test baseline: `.venv/bin/python -m pytest tests` →
180 passed.
